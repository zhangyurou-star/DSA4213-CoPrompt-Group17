"""Readable catalog of new initial requests; no hidden answers or model outputs."""
from pathlib import Path
from collections import Counter
import json
ROOT=Path(__file__).resolve().parents[1]
plan=json.loads((ROOT/'data/case_plan.json').read_text())
public={r['case_id']:r for prefix in ('design_all','validation','test') for r in (json.loads(line) for line in (ROOT/f'data/public/{prefix}_requests.jsonl').read_text().splitlines() if line)}
splits={'design':'设计','validation':'验证','test':'测试'}
domains={'constrained_writing':'受约束写作','study_planning':'学习计划'}
omissions={'complete':'信息完整','critical_omission':'关键字段缺失','critical_and_optional':'关键及可选字段缺失','optional_only':'仅可选字段缺失','unavailable_answer':'无法提供回答','execute_now':'立即执行'}
lines=['CoPrompt 全新120案例目录','','新案例清单与初始请求，不是实验结果。全部英文请求由本轮重新编写，参考日期2027-02-01。','40设计 / 20验证 / 60测试；每个分组两个领域各半。12试跑包含于设计集，20诊断包含于测试集。','本目录不展示隐藏评分答案或作者可行示例。','']
for split in splits:
 entries=[e for e in plan['cases'] if e['split']==split];counts=Counter(e['omission_type'] for e in entries)
 lines += [f'{splits[split]}集：{len(entries)}例',' / '.join(f'{omissions[k]} {counts[k]}' for k in omissions),'']
 for e in entries:
  cid=e['case_id'];marks=[]
  if cid in plan['pilot_case_ids']:marks.append('12例试跑之一')
  if cid in plan['diagnostic_case_ids']:marks.append('20例诊断之一')
  lines += [f"{cid}  {e['title_zh']}  | {domains[e['domain']]} | {omissions[e['omission_type']]}"+(' | '+', '.join(marks) if marks else ''),f"家族：{e['family_id']}",public[cid]['initial_request'],'']
(ROOT/'data/120新案例目录.txt').write_text('\n'.join(lines)+'\n')
print('Readable catalog:120 cases.')
