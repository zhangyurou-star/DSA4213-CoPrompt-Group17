"""Show this fresh experiment's saved stage counts and shared budget without API calls."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from coprompt import formal


def status(root=ROOT):
    root = Path(root).resolve()
    stages = {}
    for stage, expected in formal.PLANNED_TRAJECTORIES.items():
        path = root / f'runs/formal_v0.6.0_{stage}/manifest.json'
        saved = formal.load(path) if path.exists() else {}
        stages[stage] = {'completed': saved.get('completed_trajectories', 0), 'planned': expected,
                         'status': saved.get('status', 'not_started'), 'error': saved.get('error')}
        if stage == 'pilot_a' and 'pilot_gate' in saved:
            stages[stage]['pilot_gate'] = saved['pilot_gate']
    with formal.FreshBudgetLedger(formal.CUMULATIVE_LEDGER, root) as ledger:
        formal.verify_registered_stage_sessions(root, ledger)
        budget = {'accounted_spend_usd': float(ledger.spent), 'authorized_total_usd': float(ledger.authorized),
                  'remaining_usd': float(ledger.authorized - ledger.spent),
                  'recovered_fresh_budget_transaction': ledger.recovered_transaction}
    return {'stages': stages, 'cumulative_budget': budget, 'api_calls': 0}


def main():
    result = status()
    titles = {'pilot_a': '新12案例：direct/exhaustive', 'pilot_b': '新12案例：prompt/value',
              'design': '其余28设计案例', 'validation': '完整20案例验证', 'test': '60案例测试及20条诊断'}
    for stage, item in result['stages'].items():
        print(f'{titles[stage]}：{item["completed"]}/{item["planned"]} 条；状态 {item["status"]}')
        if item.get('error'):
            print('中断信息：' + json.dumps(item['error'], ensure_ascii=False))
        if item.get('pilot_gate'):
            gate = item['pilot_gate']
            print(f'两策略均可解析并评分：{gate["paired_scored_cases"]}/12 案例；门槛 10；通过：{gate["passed"]}')
    budget = result['cumulative_budget']
    print(f'历史及本轮累计记账 ${budget["accounted_spend_usd"]:.8f}；累计上限 ${budget["authorized_total_usd"]:.2f}；剩余 ${budget["remaining_usd"]:.8f}')
    print('以上为保存的进度；继续运行时会重新核验完整证据与阶段门槛。')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
