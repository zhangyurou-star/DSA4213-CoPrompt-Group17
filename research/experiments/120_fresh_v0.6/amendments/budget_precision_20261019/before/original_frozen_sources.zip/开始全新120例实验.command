#!/bin/zsh
set -u
COPROMPT_RUN_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$COPROMPT_RUN_DIR" || exit 1
COPROMPT_PYTHON="/Users/klesmad/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"
if [[ ! -x "$COPROMPT_PYTHON" ]]; then
  COPROMPT_PYTHON="$(command -v python3)"
fi
if [[ -z "$COPROMPT_PYTHON" || ! -x "$COPROMPT_PYTHON" ]]; then
  print '需要 Python 3.10 或更新版本。'
  read '?按回车关闭。'
  exit 1
fi
print 'CoPrompt 全新120例：40设计＋20验证＋60测试。'
print '顺序：12例基础试跑→同12例另外两策略→其余28设计→20验证→60测试与20条诊断。'
print '本轮不会导入旧案例或旧响应。新实验内部的精确首响应可复用；累计账本保留全部历史费用。'
"$COPROMPT_PYTHON" tools/preflight_fresh.py
COPROMPT_STATUS=$?
if [[ $COPROMPT_STATUS -ne 0 ]]; then
  print '离线检查未通过，尚未读取密钥，也没有调用API。'
  read '?按回车关闭。'
  exit $COPROMPT_STATUS
fi
print '请在下一行的隐藏输入处输入本机 API 密钥，再按回车；屏幕不会显示字符。'
print '密钥只用于本次进程，不保存。若直接回车而未输入，请关闭并重新启动，不要在结束提示处输入密钥。'
"$COPROMPT_PYTHON" -m coprompt.formal --stage all --key-stdin
COPROMPT_STATUS=$?
"$COPROMPT_PYTHON" tools/show_status.py
if [[ $COPROMPT_STATUS -eq 0 ]]; then
  "$COPROMPT_PYTHON" tools/analyze_fresh.py
  COPROMPT_STATUS=$?
  if [[ $COPROMPT_STATUS -eq 0 ]]; then
    print '全新120例的五阶段运行和自动分析完整完成。人工内容评审仍需真实评审人填写。'
  else
    print '运行阶段已结束，但分析检查未通过。保留全部记录并把状态反馈到当前对话。'
  fi
else
  print '实验尚未完整完成；进度已保存。请把状态反馈到当前对话，不要删除缓存或重置账本。'
fi
print '现在不再接收密钥。'
read '?按回车关闭窗口。'
exit $COPROMPT_STATUS
