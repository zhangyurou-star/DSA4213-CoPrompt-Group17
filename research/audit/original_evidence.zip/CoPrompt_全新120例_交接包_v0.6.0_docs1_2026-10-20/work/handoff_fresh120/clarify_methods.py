"""Build post-run reading documents; never change frozen experiment evidence."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "experiments/120_fresh_v0.6"
OUT = STUDY / "outputs/120例全新实验分析"
AMENDMENT = STUDY / "amendments/method_documentation_20261020"
READING_PROTOCOL = "data/formal_protocol_v0.6.0_说明补全版.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, ensure_ascii=False, indent=2) + "\n" if isinstance(value, dict) else value
    path.write_text(text, encoding="utf-8")


SHORT_METHOD = """本实验的具体方法

任务与信息：120个新编英文案例分为40设计、20验证、60测试，各组写作和学习计划各半。写作字段依次为受众、语气、长度、必含内容；计划字段依次为截止日、每日可用时间、主题、优先要求。模型只能看到公开请求、参考日期、字段说明和已释放的回答。隐藏标注只在输出后评分。
字段识别：共享模型为四个字段选择初始请求中的句段编号；程序还原原文并检查编号与有限的字段语义线索。空证据或被拒绝的证据保留为未解决，记录错误，不用隐藏答案纠正。直接生成策略也经过此共享抽取步骤。
direct：不提问，直接进入共同生成流程。
exhaustive：按字段目录顺序逐个询问尚未解决、未问过的字段，包括可选字段，直到停止条件。
prompt_only：模型依据公开状态选择一个字段ASK或选择ACT，没有显式I×U计算。
value_based：每次模型为全部可问字段给出重要性I∈{0,0.5,1}、不确定性U∈{0.5,1}；控制器计算V=I×U−λ，仅当最大V>0时提问，分数并列按字段目录顺序，回答后重新评分。I表示影响很小/局部偏好/核心内容或可行性，U表示有合理默认值/不同可能答案会实质改变结果，二者不是校准概率。
交互：每次ASK只请求一个字段，模拟器返回该字段预存的available、unknown或declined回答，无额外模型调用；未知或拒答不再询问。无效及重复ASK也占一项。每条轨迹最多3项，另在ACT、无可问字段或公开execute_now时停止；停止后不再进行决策调用。
共同生成：同一Qwen模型收到初始请求、已发生的澄清、仅从可见文本解析的约束和输出结构，不收到策略标签、I/U、λ、隐藏答案或评分。写作输出text，计划输出schedule与summary。格式失败可修复一次；已有有效JSON但违反可识别公开约束时，再允许一次约束修复。该次不再做格式重试，生成阶段最多3次调用。有效修订即采用；无效修订保留先前有效稿，不按隐藏得分挑选。计划摘要由最终明细计算总时长、每日和各主题时长，并披露已识别的约束违例。
评分：写作检查词数范围及归一化后的必含字符串，计划检查日期范围、每日合计上限、主题覆盖和各主题最低总时长。每例得分=通过约束数/该例约束数，再跨案例平均；最终格式失败计0，评分器异常阻止完成。提问负担为ASK项数，包含无效和重复项。
选参与比较：20验证例分别运行λ=0、0.25、0.5；先筛平均提问≤2者，再按质量高、问题少、λ大排序；若无符合者，按问题少、质量高、λ大排序。本轮选中0.25。60测试例比较4策略；预选20例另将有效I强制为1，U、λ和预算不变。配对差的95%区间按领域分层、按案例重采样10,000次；不把策略轨迹或缓存复用视为独立样本。
模型设置：OpenRouter，qwen/qwen3-30b-a3b-instruct-2507，仅nebius/fp8路由、禁止回退，temperature=0、top_p=1、seed=20261013；抽取输出上限512 token，决策和生成各1024。提示、代码、字段目录和设置均包含在本包；无需另一个实验包。
来源与边界：数据、响应和缓存属于本轮；方法在本轮前已有开发经历，协调者知晓历史结果。此事实是来源披露，不替代上面的机制定义。缓存只允许本轮精确相同请求的首响应及完整流程结果复用。当前两位真人的内容评审尚未完成，自动分数不代表完整可用性。
"""


def main():
    freeze_path = STUDY / "data/formal_freeze_v0.6.0.json"
    freeze = load(freeze_path)
    for name, digest in freeze["files"].items():
        if sha(STUDY / name) != digest:
            raise ValueError("Frozen evidence changed: " + name)
    original_path = STUDY / "data/formal_protocol_v0.6.0.json"
    original = load(original_path)
    protocol = deepcopy(original)
    protocol["status"] = "post_run_documentation_expansion_not_a_new_preregistration"
    protocol["documentation_revision"] = {
        "id": "docs-1",
        "date": "2026-10-20",
        "timezone": "Asia/Singapore",
        "original_protocol": "data/formal_protocol_v0.6.0.json",
        "original_protocol_sha256": sha(original_path),
        "original_status": original["status"],
        "original_created_utc": original["created_utc"],
        "meaning": "运行结束后的说明补全。原 created_utc 是原协议准备时间，不是本文编写时间。仅扩写描述，不改变任何操作参数、模型提示、数据、评分、阈值规则或结果；不替代运行前冻结协议。",
        "full_method": "docs/实验方法说明.txt",
        "current_status_source": "outputs/120例全新实验分析/analysis.json",
        "frozen_snapshot_values": "selected_lambda=null、准备时预算0.25及其他准备时间字段保留原值；实际验证选中0.25，累计授权已增至2.00，均见实际结果/授权证据，不回填为事前已知。",
    }
    protocol["method_mechanisms"] = {
        "overview_zh": SHORT_METHOD,
        "source_paths": {
            "state_extraction": ["coprompt/prompts.py", "coprompt/grounding.py", "coprompt/runner.py"],
            "controller_and_simulator_boundary": ["coprompt/runner.py", "coprompt/formal.py"],
            "shared_generation": ["coprompt/prompts.py", "coprompt/runner.py", "coprompt/visible_constraints.py"],
            "scoring": ["coprompt/scoring.py"],
            "selection_and_statistics": ["coprompt/formal.py", "tools/analyze_fresh.py"],
            "model_settings": ["config/openrouter.v0.6.formal.json"],
        },
    }
    protocol["authoring_provenance"]["limits"] = (
        "本轮方法由公开句段证据抽取与校验、direct/exhaustive/prompt_only/value_based四策略、逐字段固定回答模拟器、"
        "共同JSON生成与有限格式/公开约束修复、确定性计划摘要、隐藏约束评分及案例内配对分析构成；详细规则见"
        "method_mechanisms、generation和docs/实验方法说明.txt，所需实现均在本包。"
        "该实现于本轮数据生成前已有开发经历，协调者见过历史结果；这是一项真实来源限制，不能声称零历史影响、"
        "双盲编写或方法从未经历开发。作者使用隔离上下文只建立操作边界，不证明不存在所有污染。"
    )
    generation = protocol["generation"]
    generation["constraint_repair_information"] = (
        "仅使用初始公开请求和已释放available回答构建可见约束；修复消息含同一可见约束的违例及通过/不通过的完整测量。"
        "隐藏标注、未问到的答案、可行示例和隐藏评分不进入生成或修复。"
    )
    generation["selection_of_repair"] = (
        "公开约束修复返回结构有效JSON即采用，即使仍违反约束或隐藏分数更低；结构无效则保留修复前有效稿。"
        "该额外修复没有进一步格式重试。初次生成及一次格式修复后仍无有效JSON则记格式失败；不按隐藏分数择优。"
    )
    generation["plan_summary"] = (
        "仅对结构有效的学习计划：最终schedule按日期合计minutes，按NFKC/大小写/空白归一化的topic合计minutes，"
        "再写出总时长、每日合计和各主题合计。若存在已识别公开约束违例，摘要逐项披露；没有违例时只称已识别检查通过，"
        "不声称全部用户要求都已满足；没有可识别约束或存在解析警告时另行说明。"
        "保留原模型摘要和推导记录，只替换summary，不调整schedule，不另调模型。"
    )
    generation["execution_order"] = [
        "根据可见请求/已释放回答解析有限英文约束句式，构建生成提示和输出schema。",
        "调用一次生成；严格JSON或结构无效时，最多追加一次格式修复。",
        "若得到有效结构但已识别公开约束不满足，最多追加一次公开约束修复；包含词数/字符串，日期边界、同日多行合计、主题覆盖及主题最低总时长检查。",
        "采用有效修订或保留原有效稿，确定性推导计划摘要，保存所有尝试、测量、剩余违例和最终输出。",
    ]
    generation["shared_prompt_input_exclusions"] = (
        "共同生成提示不含策略名、case_id、抽取器猜测/字段状态、I/U评分、lambda、隐藏答案及评分。"
        "模型仍收到原请求、参考日期、user_control、已发生澄清、可见约束和输出schema。"
    )
    generation["recognition_limit"] = (
        "公开约束解析器使用固定英文模板和规则，不是通用自然语言证明器；不能保证发现所有语义约束。"
        "同一生成与修复规则用于四个主策略和importance_one诊断。"
    )
    protocol["changes_from_proposal"] = [
        "规模与比较保留：120=40设计+20验证+60测试，4主策略、3问上限、20例重要性固定为1的诊断。不是80例fallback的结果，也未把旧结果合并。",
        "本轮开始前即固定提示、字段规则、评分和共同生成机制；40设计仅检查流程，没有在看本轮结果后继续调方法。proposal原计划允许设计阶段开发后冻结。执行方法具体定义见method_mechanisms与generation。",
        "案例生产改为两位使用隔离上下文的领域作者加协调者离线核查；不是五位成员各编24例且完成真人交叉复核。协调者已有历史开发知识。编写前分配与家族记录、四项离线修正均保留。",
        "共享抽取细化为选择公开原文句段编号并进行有限字段语义核验；不按隐藏答案纠正错误。",
        "除proposal允许的每次格式失败最多修复1次外，对结构有效但违反已识别公开约束的生成结果额外修复最多1次；仅看可见信息，修订有效即采用，生成最多3次调用。详见generation。",
        "对学习计划从最终schedule确定性生成总时长、日期及主题合计摘要，披露已识别违例；不改schedule、不读取隐藏评分，不再调用模型。",
        "lambda选参保留质量优先且平均问题≤2的规则，并明确质量/问数仍相同时取较大lambda；若无合格候选则依次问题少、质量高、lambda大。这是事前已定的实现细则。",
        "两名真人评审未在案例编写前指定，目前只备好独立随机顺序和策略身份隐藏材料，尚未完成200次真人评价；不能称已完成proposal要求的真人评审或双盲。",
        "proposal规划预算15美元（含3美元恢复/演示预留）；本地运行由用户累计授权账本逐请求硬拦截。原准备快照为0.25美元，运行前/期间实际授权记录为2美元上限，包含历史支出；文档补全不增加授权或费用。",
        "proposal提及Streamlit演示；本交接包含实验命令入口和离线HTML评审表，不将评审网页称为已完成的Streamlit智能体演示。",
    ]
    write(STUDY / READING_PROTOCOL, protocol)
    write(STUDY / "当前版本阅读说明.txt", """CoPrompt 全新120例：当前阅读入口
实验版本 v0.6.0 + budget-precision-1；文档说明修订 docs-1
文档日期：2026-10-20（Asia/Singapore）

先读：
1. docs/实验方法说明.txt：完整方法，含字段识别、四策略、模拟回答、生成/修复、评分、选参、统计及proposal差异。无需旧80例文件。
2. data/formal_protocol_v0.6.0_说明补全版.json：逐字段展开的协议阅读版，特别补齐authoring_provenance.limits、generation、changes_from_proposal。运行后编写，不是新预注册。
3. outputs/120例全新实验分析/结果与方法说明.txt：具体方法和原始简要结果。
4. outputs/120例全新实验分析/本轮结果解读.txt：结果解释与下一步。
5. outputs/120例全新实验分析/人工评审表/：待真人阅读、填写及导出。不要把协调人结果报告/策略映射给身份隐藏评审者。

原始冻结记录为什么还在：
README.txt、data/formal_protocol_v0.6.0.json、config/openrouter.v0.6.formal.json及源程序属于运行时校验的71文件，故保留逐字原样。
其中“沿用”“v0.4”等是开发来源记录，具体机制已由上述方法说明完整列出；理解当前方法不需要另找旧交接包。
selected_lambda=null及0.25美元准备预算是准备时快照，不能当当前状态。验证实际选出lambda=0.25；实际累计预算上限2美元。自动120例/480轨迹已完成，人评待完成。
没有在运行结束后改写原协议/冻结哈希、调整评分、重新选参或重跑模型。修订记录与旧报告副本见amendments/method_documentation_20261020/。

配置解读：
模型qwen/qwen3-30b-a3b-instruct-2507，OpenRouter接口，仅nebius/fp8路由且禁止回退；temperature=0、top_p=1、seed=20261013。
抽取512、决策1024、生成1024是各阶段输出token上限，不是总调用量。固定seed不保证托管推理完全确定。
config的max_cost_usd=0.1是单会话限制，max_api_calls=1000是单会话调用上限；另有项目顶层账本逐请求控制累计2美元。这三个限制不是可相互替代的数字。
setup_change_note中的历史来源是相同实现的溯源，本轮实际提示与方法副本就在coprompt/。顶层必要源码/配置副本只用于冻结一致性校验，已随包提供。
""")
    write(STUDY / "data/协议阅读顺序.txt", """请先阅读 formal_protocol_v0.6.0_说明补全版.json 和 ../docs/实验方法说明.txt。

formal_protocol_v0.6.0.json 是实际执行绑定的冻结原件，保留字节不变供复核。
“说明补全版”在运行后解释原件所用的具体方法，不改参数、提示、评分和结果，也不冒充事前记录。
原件中的历史方法来源、预算准备值及selected_lambda=null仍可审计；当前状态见说明补全版的documentation_revision及结果目录。
""")
    write(OUT / "结果与方法说明.txt",
          "CoPrompt 全新120例：方法与结果阅读版\n文档修订 docs-1，2026-10-20（Asia/Singapore）\n"
          "以下先解释实际方法，再完整收录冻结分析器生成的结果说明。数值和结论没有重新选择或改写。\n"
          "详细方法：../../docs/实验方法说明.txt；原始统计：analysis.json。\n\n" +
          SHORT_METHOD + "\n原始分析器结果（下文逐字保留）\n\n" +
          (OUT / "结果说明.txt").read_text(encoding="utf-8"))
    documentation = [
        STUDY / READING_PROTOCOL, STUDY / "docs/实验方法说明.txt",
        STUDY / "当前版本阅读说明.txt", STUDY / "data/协议阅读顺序.txt",
        OUT / "结果与方法说明.txt", OUT / "本轮结果解读.txt",
        ROOT / "work/handoff_fresh120/README.txt", Path(__file__).resolve(),
    ]
    for path in documentation:
        if not path.is_file():
            raise ValueError("Missing documentation: " + str(path))
    before_files = ["handoff_README.txt", "本轮结果解读.txt"]
    for name in before_files:
        if not (AMENDMENT / "before" / name).is_file():
            raise ValueError("Missing pre-edit snapshot: " + name)
    protected = {}
    for folder in ("runs", "data/public", "data/private", "config", "coprompt", "tests"):
        for path in (STUDY / folder).rglob("*"):
            if path.is_file() and "__pycache__" not in path.parts and path.suffix not in (".pyc", ".lock"):
                protected[str(path.relative_to(STUDY))] = sha(path)
    for name in ("analysis.json", "结果说明.txt", "评审员1_独立评分表.json",
                 "评审员2_独立评分表.json", "private/评审策略映射_仅协调人.json"):
        protected[str((OUT / name).relative_to(STUDY))] = sha(OUT / name)
    write(AMENDMENT / "amendment.json", {
        "revision": "docs-1",
        "recorded_utc": datetime.now(timezone.utc).isoformat(),
        "client_date": "2026-10-20",
        "client_timezone": "Asia/Singapore",
        "kind": "post_run_documentation_only",
        "reason": "Make the current 120-case handoff understandable without historical experiment packages.",
        "is_new_preregistration": False,
        "api_calls": 0,
        "freeze_sha256_unchanged": sha(freeze_path),
        "frozen_files_verified_unchanged": len(freeze["files"]),
        "frozen_originals": "Original protocol, README, config and all 71 frozen files remain byte-identical at their original paths. Expanded protocol is an explicitly post-run reading copy.",
        "changed_existing_reading_documents": {
            "work/handoff_fresh120/README.txt": {
                "before": sha(AMENDMENT / "before/handoff_README.txt"),
                "after": sha(ROOT / "work/handoff_fresh120/README.txt"),
            },
            "experiments/120_fresh_v0.6/outputs/120例全新实验分析/本轮结果解读.txt": {
                "before": sha(AMENDMENT / "before/本轮结果解读.txt"),
                "after": sha(OUT / "本轮结果解读.txt"),
            },
        },
        "expanded_fields": ["authoring_provenance.limits", "generation", "changes_from_proposal",
                            "method_mechanisms", "documentation_revision"],
        "documentation_files_project_relative": {str(p.relative_to(ROOT)): sha(p) for p in documentation},
        "protected_study_evidence": protected,
        "numeric_analysis_unchanged_sha256": sha(OUT / "analysis.json"),
        "review_status": "No ratings entered, changed or fabricated.",
        "source_disclosure": "Historical method-development experience is disclosed; no historical results are pooled into the fresh study.",
    })
    print(json.dumps({"documentation_revision": "docs-1", "frozen_files_unchanged": len(freeze["files"]),
                      "reading_protocol": str(STUDY / READING_PROTOCOL), "api_calls": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
