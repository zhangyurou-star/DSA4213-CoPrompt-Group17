"""Build a self-contained current-study handoff without touching experiment evidence."""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import io
import json
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
NAME = 'CoPrompt_全新120例_交接包_v0.6.0_docs1_2026-10-20'
DEST = ROOT / 'outputs' / NAME
STUDY = Path('experiments/120_fresh_v0.6')
METHODS = ('__init__','budget','grounding','prompts','provider','runner','scoring','visible_constraints')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_file(rel):
    source = ROOT / rel
    if source.is_symlink():
        raise ValueError('Do not package symlinks: ' + str(rel))
    target = DEST / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def scan_bytes(data, label, depth=0):
    if re.search(rb'sk-or-v1-[A-Za-z0-9]{32,}|sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{40,}', data):
        raise ValueError('Potential credential found; package stopped. File: ' + label)
    if data.startswith(b'PK\x03\x04') and depth < 3:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for item in z.infolist():
                if not item.is_dir():
                    scan_bytes(z.read(item), label + '::' + item.filename, depth + 1)


def manifest():
    entries = []
    for p in sorted(DEST.rglob('*')):
        if p.is_symlink():
            raise ValueError('Symlink in package: ' + str(p.relative_to(DEST)))
        if not p.is_file() or p.name == 'PACKAGE_MANIFEST.json':
            continue
        if p.suffix in ('.pyc', '.lock') or p.name.startswith('.env') or p.name in ('.DS_Store',):
            raise ValueError('Excluded file appeared in package: ' + str(p.relative_to(DEST)))
        data = p.read_bytes()
        scan_bytes(data, str(p.relative_to(DEST)))
        entries.append({'path': str(p.relative_to(DEST)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    record = {'package': NAME, 'created_utc': datetime.now(timezone.utc).isoformat(),
              'client_date': '2026-10-20', 'client_timezone': 'Asia/Singapore',
              'active_study': str(STUDY), 'active_version': '0.6.0+budget-precision-1',
              'documentation_revision': 'docs-1',
              'documentation_status': 'Post-run method explanation; original 71 frozen files and experimental results unchanged.',
              'status': 'automated_study_complete_human_review_pending',
              'api_credentials_included': False, 'manifest_self_hash_excluded': True,
              'scope': 'Complete fresh study plus method, cumulative-cost and provenance dependencies; old model outcomes are not pooled into fresh analysis.',
              'files': entries}
    (DEST / 'PACKAGE_MANIFEST.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n')
    return record


def stage():
    if DEST.exists():
        raise ValueError('Destination already exists; preserve it and inspect before rebuilding')
    DEST.mkdir(parents=True)
    for p in (ROOT / STUDY).rglob('*'):
        if p.is_symlink():
            raise ValueError('Source symlink requires review: ' + str(p))
    if (ROOT / STUDY / 'runs/fresh_budget_transaction.json').exists():
        raise ValueError('Pending budget transaction; do not package until reconciled')
    shutil.copytree(ROOT / STUDY, DEST / STUDY,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.DS_Store', '*.lock'))
    for method in METHODS:
        copy_file(Path('coprompt') / (method + '.py'))
    for rel in ('config/openrouter.v0.4.formal.json', 'data/public/field_catalog.json',
                'data/schemas/output_constrained_writing.schema.json',
                'data/schemas/output_study_planning.schema.json', 'tools/validate_design.py',
                'runs/authorized_pilot_budget.json', 'runs/budget_authorization_changes.jsonl',
                'experiments/ACTIVE_STUDY.json', 'work/expand120_budget_audit.json'):
        copy_file(Path(rel))
    ledger = json.loads((ROOT / 'runs/authorized_pilot_budget.json').read_text())
    for ref in ledger['source_session_logs']:
        p = (ROOT / 'runs' / ref).resolve()
        copy_file(p.relative_to(ROOT))
    for split in ('design_all','validation','test'):
        for folder,kind in (('public','requests'),('private','annotations')):
            copy_file(Path('experiments/120_v0.5/data') / folder / f'{split}_{kind}.jsonl')
    (DEST / 'experiments/120_v0.5/仅作来源排查参考.txt').write_text(
        '这里仅为本轮新颖性审计保留旧请求与标注。不是当前实验，不导入本轮模型上下文、缓存或统计。\n此目录不是旧版本的完整交接包。\n')
    shutil.copytree(ROOT / 'references', DEST / 'references', ignore=shutil.ignore_patterns('.DS_Store'))
    shutil.copytree(ROOT / 'work/fresh120_review_form', DEST / 'work/fresh120_review_form',
                    ignore=shutil.ignore_patterns('__pycache__','*.pyc','.DS_Store'))
    (DEST / 'work/handoff_fresh120').mkdir(parents=True)
    for name in ('build_package.py', 'verify_fresh_handoff.py', 'clarify_methods.py', 'README.txt'):
        shutil.copy2(WORK / name, DEST / 'work/handoff_fresh120' / name)
    (DEST / 'handoff').mkdir(exist_ok=True)
    shutil.copy2(WORK / 'verify_fresh_handoff.py', DEST / 'handoff/verify_fresh_handoff.py')
    shutil.copy2(WORK / 'README.txt', DEST / 'README.txt')
    (DEST / '核验交接包.command').write_text('''#!/bin/zsh
set -u
COPROMPT_PACKAGE_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$COPROMPT_PACKAGE_DIR" || exit 1
COPROMPT_PYTHON="$(command -v python3)"
if [[ -z "$COPROMPT_PYTHON" ]]; then
  print '完整核验需要Python 3.10或更新版本。阅读报告和HTML评审表无需Python。'
  read '?按回车关闭。'
  exit 1
fi
print '离线核验交接包：不读取API密钥，不调用模型，不改写原包。'
"$COPROMPT_PYTHON" -B handoff/verify_fresh_handoff.py
COPROMPT_CHECK_STATUS=$?
if [[ $COPROMPT_CHECK_STATUS -eq 0 ]]; then
  print '核验通过。自动实验已完成；人工评审仍需真人填写。'
else
  print '核验未通过，请保留错误信息；不要修改冻结指纹来跳过检查。'
fi
read '?按回车关闭。'
exit $COPROMPT_CHECK_STATUS
''', encoding='utf-8')
    (DEST / '核验交接包.command').chmod(0o755)
    (DEST / 'handoff/打包范围说明.txt').write_text('''当前交接范围

完整保留experiments/120_fresh_v0.6内的数据、冻结方法、71文件清单、运行记录、6份本轮API会话、全部实验缓存、结果、人评材料与修订原始证据。
docs-1新增独立的方法说明、协议说明补全版、当前阅读入口及方法与结果合并阅读版，并扩写交接README和结果解读。
原冻结协议/README/配置、分析器的结果说明.txt、analysis.json及全部实验记录不变。说明补全版是在运行后编写，不是新的事前注册或新实验；旧阅读文档及变更指纹见amendments/method_documentation_20261020/。
补齐父目录的方法依赖、预算账本、16份历史费用会话、预算授权记录、proposal、页面构建源码和来源排查参考。
历史请求/标注只用于新颖性来源审计；历史会话只用于累计费用对账。新实验执行与分析均不导入旧输出。
没有复制原80例的完整测试轨迹、旧报告、旧评审表、旧响应缓存或旧交接包，避免误用为本轮成果。
排除__pycache__、pyc、.DS_Store和运行锁。未收集聊天记录、终端历史、浏览器状态或环境凭据文件。
封包时对全部文件及内嵌ZIP执行密钥形态扫描；扫描不显示疑似密钥内容。
浏览器本机自动保存的人工评审进度不在项目文件夹内，因此不在包中。开始评审后请单独导出、保管和交回最新JSON备份。
评审表已完成离线逻辑与材料一致性核验；因浏览器安全策略阻止本地HTML预览，未完成浏览器实测。
打包和核验均未调用模型、未产生API支出、未预填人工评价。
''', encoding='utf-8')
    return manifest()


def seal():
    receipt = WORK / 'verification_receipt.json'
    if not receipt.exists() or json.loads(receipt.read_text()).get('status') != 'complete_fresh120_handoff_verified':
        raise ValueError('A successful full verification receipt is required before sealing')
    if json.loads(receipt.read_text()).get('verified_manifest_sha256') != sha(DEST / 'PACKAGE_MANIFEST.json'):
        raise ValueError('The staging manifest differs from the one fully verified; verify again before sealing')
    shutil.copy2(receipt, DEST / 'handoff/交接前核验记录.json')
    record = manifest()
    # The experiment version includes dots in the directory name; append, never replace its suffix.
    archive = DEST.parent / (DEST.name + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(DEST.rglob('*')):
            if p.is_file():
                z.write(p, str(Path(NAME) / p.relative_to(DEST)))
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise ValueError('Archive CRC check failed')
        for item in record['files']:
            raw = z.read(str(Path(NAME) / item['path']))
            if len(raw) != item['bytes'] or hashlib.sha256(raw).hexdigest() != item['sha256']:
                raise ValueError('Archive member differs from manifest: ' + item['path'])
        assert z.read(str(Path(NAME) / 'PACKAGE_MANIFEST.json')) == (DEST / 'PACKAGE_MANIFEST.json').read_bytes()
    digest = sha(archive)
    checksum = archive.with_name(archive.name + '.sha256.txt')
    checksum.write_text(digest + '  ' + archive.name + '\n')
    return {'archive': str(archive), 'expanded_directory': str(DEST), 'bytes': archive.stat().st_size,
            'files': len(record['files']) + 1, 'sha256': digest,
            'receipt': str(DEST / 'handoff/交接前核验记录.json')}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('stage','seal'))
    args = parser.parse_args()
    result = stage() if args.action == 'stage' else seal()
    if args.action == 'stage':
        result = {'staged': str(DEST), 'files': len(result['files']) + 1}
    print(json.dumps(result, ensure_ascii=False, indent=2))
