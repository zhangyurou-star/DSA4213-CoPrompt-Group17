"""Build offline review forms exclusively from this fresh study's masked packets."""
from pathlib import Path
import hashlib
import json
import zipfile

BASE = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
SOURCE = BASE / 'experiments/120_fresh_v0.6/outputs/120例全新实验分析'
DEST = SOURCE / '人工评审表'


def main():
    DEST.mkdir(exist_ok=True)
    template = (WORK / 'template.html').read_text()
    assert template.count('__PACKET__') == 1
    manifest = {'form_version': 'fresh120-review-form-1', 'sources': [], 'outputs': [],
                'model_calls': 0, 'original_packets_modified': False,
                'private_strategy_mapping_included': False}
    for slot in (1, 2):
        source = SOURCE / f'评审员{slot}_独立评分表.json'
        raw = source.read_bytes()
        packet = json.loads(raw)
        assert packet['reviewer_slot'] == slot and len(packet['records']) == 100
        assert len({r['review_item_id'] for r in packet['records']}) == 100
        forbidden = {'system_id', 'case_id', 'score', 'lambda_value', 'importance_override', 'underlying_policy'}
        assert all(not forbidden.intersection(r) for r in packet['records'])
        material = {'source_packet_sha256': hashlib.sha256(raw).hexdigest(), 'packet': packet}
        payload = json.dumps(material, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
        target = DEST / f'评审员{slot}_阅读填写表.html'
        target.write_text(template.replace('__PACKET__', payload), encoding='utf-8')
        manifest['sources'].append({'file': source.name, 'sha256': material['source_packet_sha256']})
        manifest['outputs'].append({'file': target.name, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'records': 100})
        assert source.read_bytes() == raw
    (DEST / '使用说明.txt').write_text('''CoPrompt 全新120例实验 · 人工内容评审

给协调人
本轮人工评审使用预选20个测试案例、每例5份输出。每位评审者100份，两位共200次评价；不把120个案例全部作为正式人评，也不把20例诊断当独立新增样本。
请分别将“评审员1_阅读填写表.html”和“评审员2_阅读填写表.html”发给两位评审者。每人只使用分配的一份，不看另一人的表、策略映射、自动得分或结果报告。不要让同一人填写两份后称为双人独立评审。
两份表保留各自既有匿名编号和随机顺序，没有合并相同输出，也没有任何预填评分。是否实际盲评、是否符合作者/交叉复核排除条件，仍由协调人如实确认。

给评审人
1. 双击分配给你的HTML文件，用Safari、Chrome或Edge打开。全部材料已嵌入，离线可用，无需登录或API密钥。
2. 填写姓名或代号。在“评审说明与声明”中按实际情况填写；不知道的保持未确认，页面不会自动替你认定独立或盲评。
3. 按顺序阅读原始请求、参考日期、用户控制要求、实际问答与答复状态、最终输出。英文原文没有翻译或改写；学习计划以表格展示，并保留原摘要。
4. 填写四项1—5分及两项非负整数计数。无法判断时勾选该维度“无法判断”，并在备注中解释；空白不会变成0。可选问题不自动等于不必要问题。
5. 勾选三项阅读确认，点击“确认本份”。修改已确认的评分或备注后，该份会重新变成草稿，需要重新阅读勾选并确认。
6. 浏览器会尝试本机自动保存；每次结束一段评审都点击“导出备份”。保留下载的JSON文件，换浏览器或电脑时点击“导入备份”恢复。自动保存依赖当前浏览器与文件位置，不能替代导出的备份。
7. “导出评分CSV”用于表格汇总。正式评分列只包含已确认的评价；草稿保留在JSON备份中。尚未评价与明确填0会分别保留。
8. “打印本份”可打印当前阅读材料和填写情况；需要离线手写时可在未填状态打印。不会一次打印全部100份。

交回什么
每位评审者交回自己的最新JSON备份；可另附评分CSV。包含“无法判断”的已确认记录会单独计数，后续仍需核查，不能作为六项评分都齐全。
JSON保留原始评审包的记录结构、来源指纹、评审者声明和已确认ratings；另有review_form_state保存草稿及勾选。不要手工改动原始输出。HTML填写不会覆写源JSON，也不会调用模型或自动提交到服务器。
所有判断均需真人完成。材料整理与页面自动保存，不代表人工评审已完成。
''', encoding='utf-8')
    archive = DEST.parent / '120例人工评审材料.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(DEST.glob('*.html')):
            z.write(p, p.name)
        z.write(DEST / '使用说明.txt', '使用说明.txt')
    (WORK / 'build_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'reviewers': 2, 'records_each': 100, 'output': str(DEST), 'archive': str(archive)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
