#!/bin/zsh
set -u
COPROMPT_PACKAGE_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$COPROMPT_PACKAGE_DIR" || exit 1
COPROMPT_PYTHON="$(command -v python3)"
if [[ -z "$COPROMPT_PYTHON" ]]; then
  print '完整核验需要Python 3.10或更新版本。阅读报告和HTML评审表无需Python。'
  read '?按回车关闭。'
  exit 1
fi
print '离线核验交接包：不读取API密钥，不调用模型，不改写原包。'
"$COPROMPT_PYTHON" -B handoff/verify_fresh_handoff.py
COPROMPT_CHECK_STATUS=$?
if [[ $COPROMPT_CHECK_STATUS -eq 0 ]]; then
  print '核验通过。自动实验已完成；人工评审仍需真人填写。'
else
  print '核验未通过，请保留错误信息；不要修改冻结指纹来跳过检查。'
fi
read '?按回车关闭。'
exit $COPROMPT_CHECK_STATUS
