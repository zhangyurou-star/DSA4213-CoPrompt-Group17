"""Verify a relocated fresh120 handoff. Original package files are never rewritten.

Python 3.10+, macOS/Linux/WSL. Model access is neither needed nor performed.
The frozen offline analysis and mock-based tests run only inside a disposable copy.
"""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
STUDY = Path('experiments/120_fresh_v0.6')


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe(root, name):
    if not isinstance(name, str) or Path(name).is_absolute():
        raise ValueError('Expected a relative package path')
    p = root / name
    if p.is_symlink():
        raise ValueError('Symlink not allowed: ' + name)
    p.resolve().relative_to(root.resolve())
    return p


def verify_files():
    manifest = load(ROOT / 'PACKAGE_MANIFEST.json')
    files = manifest['files']
    if len(files) != len({x['path'] for x in files}):
        raise ValueError('Duplicate manifest paths')
    for item in files:
        p = safe(ROOT, item['path'])
        if not p.is_file() or p.stat().st_size != item['bytes'] or sha(p) != item['sha256']:
            raise ValueError('Missing or changed package file: ' + item['path'])
    freeze = load(ROOT / STUDY / 'data/formal_freeze_v0.6.0.json')
    for name, digest in freeze['files'].items():
        if sha(safe(ROOT / STUDY, name)) != digest:
            raise ValueError('Frozen evidence changed: ' + name)
    return len(files), len(freeze['files'])


def comparable(result):
    result = copy.deepcopy(result)
    result.pop('created_utc', None)
    result['costs'].pop('ledger_path', None)
    return result


def verify_documentation():
    """Verify that docs-1 only explains, and does not replace, frozen evidence."""
    study = ROOT / STUDY
    amendment_dir = study / 'amendments/method_documentation_20261020'
    amendment = load(amendment_dir / 'amendment.json')
    if (amendment.get('revision') != 'docs-1'
            or amendment.get('kind') != 'post_run_documentation_only'
            or amendment.get('is_new_preregistration') is not False
            or amendment.get('api_calls') != 0):
        raise ValueError('Invalid documentation amendment')
    if sha(study / 'data/formal_freeze_v0.6.0.json') != amendment['freeze_sha256_unchanged']:
        raise ValueError('Documentation amendment refers to a different freeze')
    for name, digest in amendment['protected_study_evidence'].items():
        if sha(safe(study, name)) != digest:
            raise ValueError('Documentation changed protected experimental evidence: ' + name)
    for name, digest in amendment['documentation_files_project_relative'].items():
        if sha(safe(ROOT, name)) != digest:
            raise ValueError('Documentation differs from amendment: ' + name)
    for name, before in (
        ('work/handoff_fresh120/README.txt', 'handoff_README.txt'),
        (str(STUDY / 'outputs/120例全新实验分析/本轮结果解读.txt'), '本轮结果解读.txt'),
    ):
        entry = amendment['changed_existing_reading_documents'][name]
        if sha(amendment_dir / 'before' / before) != entry['before'] or sha(safe(ROOT, name)) != entry['after']:
            raise ValueError('Documentation before/after record differs: ' + name)
    original = load(study / 'data/formal_protocol_v0.6.0.json')
    reading = load(study / 'data/formal_protocol_v0.6.0_说明补全版.json')
    if reading['documentation_revision']['original_protocol_sha256'] != sha(study / 'data/formal_protocol_v0.6.0.json'):
        raise ValueError('Reading protocol points to a different original')
    # Only these descriptive fields may differ. All experimental parameters,
    # selection rules, case lists and budget snapshots must retain original values.
    cleaned = copy.deepcopy(reading)
    del cleaned['documentation_revision']
    del cleaned['method_mechanisms']
    cleaned['status'] = original['status']
    cleaned['authoring_provenance']['limits'] = original['authoring_provenance']['limits']
    cleaned['changes_from_proposal'] = original['changes_from_proposal']
    for name in ('execution_order', 'shared_prompt_input_exclusions', 'recognition_limit'):
        del cleaned['generation'][name]
    for name in ('constraint_repair_information', 'selection_of_repair', 'plan_summary'):
        cleaned['generation'][name] = original['generation'][name]
    if cleaned != original:
        raise ValueError('Reading protocol changes more than the declared documentation fields')
    out = study / 'outputs/120例全新实验分析'
    if not (out / '结果与方法说明.txt').read_text().endswith((out / '结果说明.txt').read_text()):
        raise ValueError('Combined reading report does not preserve original summary text')
    section = '2. 主要结果：仅使用全新60例测试'
    old = (amendment_dir / 'before/本轮结果解读.txt').read_text()
    new = (out / '本轮结果解读.txt').read_text()
    if old.split(section, 1)[1] != new.split(section, 1)[1]:
        raise ValueError('Results and conclusions changed in the reading report')
    return {'revision': 'docs-1', 'frozen_originals_unchanged': True,
            'protocol_operational_parameters_unchanged': True,
            'protected_evidence_files': len(amendment['protected_study_evidence']),
            'report_results_and_conclusions_unchanged': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-only', action='store_true', help='Only verify packaged file hashes')
    parser.add_argument('--node', help='Optional Node 18+ executable for the reviewer-form logic checks')
    parser.add_argument('--export-analysis', type=Path, help='Optional NEW output directory for recomputed analysis')
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        raise ValueError('Python 3.10 or newer is required')
    n_files, n_frozen = verify_files()
    documentation = verify_documentation()
    verified_manifest_hash = sha(ROOT / 'PACKAGE_MANIFEST.json')
    result = {'status': 'package_hashes_verified', 'verified_utc': datetime.now(timezone.utc).isoformat(),
              'package_files_verified': n_files, 'frozen_files_verified': n_frozen,
              'api_calls': 0, 'original_package_files_modified': False,
              'documentation': documentation,
              'verified_manifest_sha256': verified_manifest_hash}
    if args.manifest_only:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    if sys.platform == 'win32':
        raise ValueError('Full experiment verification requires macOS, Linux or WSL (fcntl dependency). HTML review forms work on Windows.')
    if args.export_analysis and args.export_analysis.exists():
        raise ValueError('Export destination already exists; choose a new folder to preserve existing work')
    with tempfile.TemporaryDirectory(prefix='coprompt-fresh120-check-') as folder:
        relocated = Path(folder) / 'project'
        relocated.mkdir()
        # Only verified members enter the execution copy. Extra notes or local
        # modules in the received folder cannot affect imports in this check.
        members = load(ROOT / 'PACKAGE_MANIFEST.json')['files']
        for member in members:
            source = safe(ROOT, member['path'])
            target = safe(relocated, member['path'])
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        shutil.copy2(ROOT / 'PACKAGE_MANIFEST.json', relocated / 'PACKAGE_MANIFEST.json')
        study = relocated / STUDY
        sys.path.insert(0, str(study))
        from coprompt import formal
        from tools.preflight_fresh import preflight
        preflight_result = preflight(study)
        spec = importlib.util.spec_from_file_location('handoff_fresh_analysis', study / 'tools/analyze_fresh.py')
        analysis_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(analysis_module)
        recomputed = analysis_module.analyze(study, project_root=relocated)
        saved = load(ROOT / STUDY / 'outputs/120例全新实验分析/analysis.json')
        if comparable(saved) != comparable(recomputed):
            raise ValueError('Recomputed analysis differs from the saved evidence beyond timestamp/path')
        tests = subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-q'],
                               cwd=study, text=True, capture_output=True, timeout=120)
        if tests.returncode:
            raise ValueError('Offline regression tests failed:\n' + tests.stdout + tests.stderr)
        result.update(status='complete_fresh120_handoff_verified',
                      completed_logical_trajectories=recomputed['completed_trajectories']['total'],
                      dataset_cases=recomputed['dataset_cases'], selected_lambda=recomputed['validation_selection']['selected_lambda'],
                      cumulative_accounted_usd=recomputed['costs']['cumulative_accounted_usd'],
                      fresh_accounted_usd=recomputed['costs']['fresh_accounted_usd'],
                      authorized_total_usd=recomputed['costs']['authorized_total_usd'],
                      original_analysis_reproduced=True, checks=recomputed['checks'],
                      offline_test_summary=(tests.stdout + tests.stderr).strip(),
                      preflight=preflight_result['status'], human_review='pending_actual_reviewers',
                      relocated_copy_used=True)
        if args.node:
            form = subprocess.run([args.node, str(relocated / 'work/fresh120_review_form/check_logic.cjs')],
                                  text=True, capture_output=True, timeout=60)
            if form.returncode:
                raise ValueError('Reviewer form logic checks failed:\n' + form.stdout + form.stderr)
            result['review_form_logic'] = json.loads(form.stdout)
        if args.export_analysis:
            target = args.export_analysis.expanduser().resolve()
            if target.is_relative_to(ROOT):
                raise ValueError('Export outside the handoff package to preserve the snapshot')
            shutil.copytree(study / 'outputs/120例全新实验分析', target)
            result['recomputed_analysis_exported_to'] = str(target)
    verify_files()
    if sha(ROOT / 'PACKAGE_MANIFEST.json') != verified_manifest_hash:
        raise ValueError('Package manifest changed during verification')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, ImportError, subprocess.SubprocessError) as error:
        print('核验失败 / Verification failed: ' + str(error), file=sys.stderr)
        sys.exit(1)
